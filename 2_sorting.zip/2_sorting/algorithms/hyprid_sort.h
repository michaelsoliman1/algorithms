#include <vector>

class HypridSort {
public:
    static void sort(std::vector<int> list)
    {

    };
};